import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/tasks.dart';
import '../provider.dart';
import '../widgets/add_task_dialog.dart';
import '../widgets/app_drawer.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  DateTime selectedDate = DateTime.now();

  List<Task> get filteredTasks {
    final provider = context.watch<TaskProvider>();

    return provider.tasks.where((task) {
      return task.date.day == selectedDate.day &&
          task.date.month == selectedDate.month &&
          task.date.year == selectedDate.year;
    }).toList();
  }


  bool addTask(String title, TimeOfDay startTime, TimeOfDay endTime) {
    final provider = context.read<TaskProvider>();

    final newTask = Task.fromTime(
      title: title,
      date: selectedDate,
      startTime: startTime,
      endTime: endTime,
    );

    final hasConflict = provider.tasks.any((task) {
      if (task.date.day != selectedDate.day ||
          task.date.month != selectedDate.month ||
          task.date.year != selectedDate.year) {
        return false;
      }

      final newStart = startTime.hour * 60 + startTime.minute;
      final newEnd = endTime.hour * 60 + endTime.minute;

      final existingStart = task.startTime.hour * 60 + task.startTime.minute;
      final existingEnd = task.endTime.hour * 60 + task.endTime.minute;

      return newStart < existingEnd && newEnd > existingStart;
    });

    if (hasConflict) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Время пересекается!")),
      );
      return false;
    }

    provider.addTask(newTask);
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const AppDrawer() ,
      backgroundColor: const Color(0xFF4143D1),
      appBar: AppBar(
        backgroundColor: const Color(0xFF4143D1),
        title: Text(
          "${selectedDate.day} ${[
            'january', 'february', 'march', 'april', 'may', 'june',
            'july', 'august', 'september', 'october', 'november', 'december'
          ][selectedDate.month - 1]}",
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        leading: Builder(
            builder: (context) {
              return IconButton(
                onPressed: () {
                  Scaffold.of(context).openDrawer();
                },
                icon: const Icon(Icons.menu,color: Colors.white),);
            }
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: const Icon(Icons.timer, color: Colors.white),
          )
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 40),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Today",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "${filteredTasks.length} Tasks",
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 20),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  ),
                  onPressed: () => openAddTaskDialog(
                    context: context,
                    selectedDate: selectedDate,
                    onSubmit: addTask,
                  ),
                  child: const Text(
                    "Add Task",
                    style: TextStyle(fontSize: 20, color: Color(0xFF4143D1)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 40),
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(50),
                ),
              ),
              width: double.infinity,
              child: Column(
                children: [
                  SizedBox(
                    height: 80,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 40),
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: 7,
                        itemBuilder: (context, index) {
                          final date = DateTime.now().add(Duration(days: index));

                          final isSelected = date.day == selectedDate.day &&
                              date.month == selectedDate.month;

                          return GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedDate = date;
                              });
                            },
                            child: Container(
                              width: 60,
                              margin: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? const Color(0xFF4143D1)
                                    : Colors.grey[200],
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    "${date.day}",
                                    style: TextStyle(
                                      color: isSelected ? Colors.white : Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
                                    [date.weekday - 1],
                                    style: TextStyle(
                                      color:
                                      isSelected ? Colors.white70 : Colors.black54,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  Expanded(
                    child: filteredTasks.isEmpty
                        ? Center(
                      child: Text(
                        "No tasks for this day",
                        style: TextStyle(color: Colors.grey.shade400),
                      ),
                    )
                        : ListView.builder(
                      itemCount: filteredTasks.length,
                      itemBuilder: (context, i) {
                        final task = filteredTasks[i];

                        return Dismissible(
                          key: ValueKey(task),
                          direction: DismissDirection.horizontal,
                          background: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                              padding: const EdgeInsets.symmetric(horizontal: 20),
                              alignment: Alignment.centerLeft,
                              decoration: BoxDecoration(
                                color: Colors.green.shade400,
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child:  const Icon(Icons.check_circle_outline, color: Colors.white)),
                          secondaryBackground: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            alignment: Alignment.centerRight,
                            decoration: BoxDecoration(
                              color: Colors.red.shade400,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: const Icon(Icons.delete_outline, color: Colors.white),
                          ),
                          confirmDismiss: (direction) async {
                            if (direction == DismissDirection.startToEnd) {
                              setState(() {
                                task.isDone = !task.isDone;
                              });
                              return false;
                            }
                            else return await showDialog<bool>(
                              context: context,
                              builder: (context) => AlertDialog(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                title: const Text("Delete task?"),
                                content: Text("Delete \"${task.title}\"?"),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context, false),
                                    child: const Text("Cancel"),
                                  ),
                                  TextButton(
                                    onPressed: () => Navigator.pop(context, true),
                                    child: const Text(
                                      "Delete",
                                      style: TextStyle(color: Colors.red),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                          onDismissed: (direction) {
                            setState(() {
                              context.read<TaskProvider>().deleteTask(task);
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text("\"${task.title}\" deleted")),
                            );
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                            padding: const EdgeInsets.all(15),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black12,
                                  blurRadius: 5,
                                  offset: const Offset(0, 2),
                                )
                              ],
                            ),
                            child: Row(
                              children: [
                                Checkbox(
                                  value: task.isDone,
                                  onChanged: (value) {
                                    context.read<TaskProvider>().toggleTask(task);
                                  },
                                ),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        task.title,
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          decoration: task.isDone
                                              ? TextDecoration.lineThrough
                                              : TextDecoration.none,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        "${task.startTime.hour.toString().padLeft(2, '0')}:${task.startTime.minute.toString().padLeft(2, '0')} - "
                                            "${task.endTime.hour.toString().padLeft(2, '0')}:${task.endTime.minute.toString().padLeft(2, '0')}",
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey.shade600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}